/*\
title: hasOwnProperty/program.js
type: application/javascript
module-type: library

OwnProperty test

\*/

var hasOwnProperty = require('hasOwnProperty');
var toString = require('toString');
var test = require('test');
test.print('DONE', 'info');


