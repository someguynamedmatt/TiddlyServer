/*\
title: submodule/a.js
type: application/javascript
module-type: library

Relative test A

\*/



exports.foo = require('./b').foo;

